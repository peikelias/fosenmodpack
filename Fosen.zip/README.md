# Fosen's eneste modpack


## Changelog

### v1.0.5
- Lagt til [lethalThings](https://thunderstore.io/c/lethal-company/p/Evaisa/LethalThings/) mod
   >**Inneholder**
	- 7 scrap, 
	- 5 store items (Remote radar, Hacking tool for dører etc, utility belt, rocket lchr, hammer)
	- 1 stk enemy roomba
	- 3 decor (Skiltet i skipet teller dager uten dødsfall)
	- 1 map hazard (Teleporter trap)
	- 1 game mechanic
	
- Opprettet git-repo

### v1.0.4
- Oppdatert alle mods

- Lagt til følgende mods:
    1. **HornMoan-2.1.0**
		- Lyder <3
    2. **LethalPosters-1.2.0**
		- Custom posters
    3. **WeatherMultipliers-1.0.0**
		- Dritt jobb = Mere cash
    4. **FixCentipedeLag-2023.12.7**
		- Mindre lagg ?
    5. **MoreScreams-1.0.3**
		- Hører voice i 2 sek etter at folk dør
    6. **BetterTeleporter-1.1.1**
		- Mister ikke nøkkler, lys, walkie-talkie
		- Man mister 50% lading av lys, walkie-talkie når man bruker teleport.
    7. **TerminalExtras-1.0.1**
		- Ekstra kommandoer i terminalen
    		- Door - Toggles the door.
    		- Teleport - Activates the teleporter.
    		- Lights - Toggle the lights.
    		- Launch - Pulls the ship lever.
    8. **ScalingStartCredits-1.0.1**
        - Ekstra start cash om man er flere på runde 1
    9. **EladsHUD-1.1.0**
        - Ny HUD?
    10. **HideModList-1.0.1**
        - Fjerner mod liste fra loading 
    11. **HealthStation-1.0.1**
        - Lade lys og annet stash? 
          Lader nå også liv
    12. **CoomfyDungeon-1.0.11**
        - Scaler spawn av lott og størrelse på map etter antall spillere
        - Bedre map generering
    13. **EmployeeAssignments-1.0.5**
        - Custom oppdrag til alle spillerne
    14. **Boombox_Controller-1.1.0**
        - Custom sanger til boombox
        - /bhelp - View all commands
        - Støtter Youtube, Soundcloud og linker til .mp3



### v1.0.3
Lagt til no penalty og byttet suit mod

### v1.0.2

Lagt til Discord rich presence
Mod oppdatering

### v1.0.1

Mod oppdatering

### v1.0.0

Må da start enplass